"""
Errors module for the expected issues.
"""


class ContactError(Exception):
    pass


class EmptyBookError(Exception):
    pass
